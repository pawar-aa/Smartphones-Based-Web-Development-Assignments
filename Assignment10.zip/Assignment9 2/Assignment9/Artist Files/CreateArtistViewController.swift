
import UIKit
import CoreData

class CreateArtistViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var artistImageView: UIImageView!
    @IBOutlet weak var selectImageButton: UIButton!
    @IBOutlet weak var createArtistButton: UIButton!
        
        let managedObjectContext: NSManagedObjectContext = {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            return appDelegate.persistentContainer.viewContext
        }()
        
        var artists = [Artist]()
        var selectedImage: UIImage?
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Set up the image selection button
            selectImageButton.addTarget(self, action: #selector(selectImageButtonTapped(_:)), for: .touchUpInside)
            
            // Set up the image view tap gesture
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped(_:)))
            artistImageView.isUserInteractionEnabled = true
            artistImageView.addGestureRecognizer(tapGesture)
            
            fetchArtists()
            // Set up "Create Artist" button
            createArtistButton.addTarget(self, action: #selector(createArtistButtonTapped(_:)), for: .touchUpInside)
        }
        
        @objc func selectImageButtonTapped(_ sender: UIButton) {
            let imagePickerController = UIImagePickerController()
            imagePickerController.delegate = self
            imagePickerController.sourceType = .photoLibrary
            present(imagePickerController, animated: true, completion: nil)
        }
    
    // Action method for the "Create Artist" button
       @objc func createArtistButtonTapped(_ sender: UIButton) {
           // Check if name is provided
           guard let name = nameTextField.text, !name.isEmpty else {
               showAlert(message: "Please enter artist name.")
               return
           }
           
           guard let selectedImageData = selectedImage?.jpegData(compressionQuality: 1.0) else {
               showAlert(message: "Please select an image for the Artist.")
               return
           }
           
           // Create a new artist entity
           let artistEntity = NSEntityDescription.entity(forEntityName: "Artist", in: managedObjectContext)!
           let newArtist = NSManagedObject(entity: artistEntity, insertInto: managedObjectContext) as! Artist
           
           // Set artist properties
           newArtist.name = name
           // Set artist image if available
           if let imageData = selectedImage?.jpegData(compressionQuality: 1.0) {
               newArtist.image = imageData
           }
           
           // Save the changes to Core Data
           do {
               dismiss(animated: true) {
                   NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
               }
               
               // Show success message
                       showAlert(message: "Artist created successfully.")

                       // Reset all fields
                       resetFields()

                       // Dismiss the view controller
                       dismiss(animated: true) {
                           NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
                       }
           } catch let error as NSError {
               print("Error saving artist: \(error), \(error.userInfo)")
               showAlert(message: "Failed to create artist.")
           }
       }
    
    func resetFields() {
        nameTextField.text = ""
        artistImageView.image = nil
        selectImageButton.isHidden = false
    }
    
    // Function to display an alert with a given message
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                selectedImage = image
                artistImageView.image = image
                selectImageButton.isHidden = true // Hide the button when an image is selected
            }
            dismiss(animated: true, completion: nil)
        }
        
        @objc func imageViewTapped(_ sender: UITapGestureRecognizer) {
            selectImageButton.isHidden = false // Show the button when the image view is tapped
        }
        
        func fetchArtists() {
            let fetchRequest: NSFetchRequest<Artist> = Artist.fetchRequest()
            
            do {
                artists = try managedObjectContext.fetch(fetchRequest)
            } catch {
                print("Error fetching artists: \(error)")
            }
        }
        
        // Add any additional methods or functionality here as needed
        

}
