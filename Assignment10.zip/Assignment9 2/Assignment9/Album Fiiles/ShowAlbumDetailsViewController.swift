
import UIKit
import CoreData

class ShowAlbumDetailsViewController: UIViewController {

    var selectedAlbum: Album? // Property to hold the selected album

       @IBOutlet weak var albumArtistTextField: UITextField!
       @IBOutlet weak var albumTitleTextField: UITextField!
       @IBOutlet weak var albumSongsScrollView: UIScrollView!
       @IBOutlet weak var albumImageView: UIImageView!

       @IBOutlet weak var datePicker: UIDatePicker!
    
    let managedObjectContext: NSManagedObjectContext = {
           let appDelegate = UIApplication.shared.delegate as! AppDelegate
           return appDelegate.persistentContainer.viewContext
       }()

    override func viewDidLoad() {
        super.viewDidLoad()

        if let album = selectedAlbum {
            // Update UI with album details
            print("Album ID: \(album.id), Album Title: \(album.title ?? "Unknown"), Album artist: \(album.artistID)")
            albumTitleTextField.text = album.title
            // Convert release date string to Date object
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "MM/dd/yyyy"
                    if let releaseDateString = album.releaseDate,
                       let releaseDate = dateFormatter.date(from: releaseDateString) {
                        datePicker.date = releaseDate
                    } else {
                        datePicker.date = Date() // Set default date if conversion fails
                    }
            
            if let artist = album.artist {
                albumArtistTextField.text = artist.name
            }

            // Display album image
            if let imageData = album.image, let albumImage = UIImage(data: imageData) {
                albumImageView.image = albumImage
            }

            // Display songs associated with the album
            displayAlbumSongs()
        }

        // Disable user interaction for artist fields
        albumArtistTextField.isUserInteractionEnabled = false
    }

       @IBAction func deleteAlbumButton(_ sender: UIButton) {
           guard let selectedAlbum = selectedAlbum else {
               print("No album selected.")
               return
           }

           // Check if the album has songs
           if let songsCount = selectedAlbum.songs?.count, songsCount > 0 {
               // Show alert: "Album cannot be deleted because it has 1 or more Songs"
               let alert = UIAlertController(title: "Cannot Delete Album", message: "Album cannot be deleted because it has \(songsCount) or more Songs", preferredStyle: .alert)
               alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
               self.present(alert, animated: true, completion: nil)
           } else {
               // Delete the album from Core Data
               managedObjectContext.delete(selectedAlbum)

               do {
                   try managedObjectContext.save()
                   print("Album deleted successfully.")
                   NotificationCenter.default.post(name: NSNotification.Name(rawValue: "AlbumDeleted"), object: nil)
                   navigationController?.popViewController(animated: true) // Dismiss the view controller

                   // Dismiss the current view controller
                   dismiss(animated: true) {
                       // After dismissal, trigger a refresh of the ShowAllAlbumsController
                       NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
                   }
               } catch let error as NSError {
                   print("Error deleting album: \(error.localizedDescription)")
               }
           }
       }

    @IBAction func updateAlbumButton(_ sender: UIButton) {
        guard let selectedAlbum = selectedAlbum else {
            print("No album selected.")
            return
        }

        // Update album details with values from text fields
        if var newTitle = albumTitleTextField.text {
            selectedAlbum.title = newTitle
        }
        
        // Convert the selected date to a string
        let releaseDate = datePicker.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let newReleaseDate = dateFormatter.string(from: releaseDate)
        
        // Assign the new release date to the selected album
        selectedAlbum.releaseDate = newReleaseDate

        do {
            try managedObjectContext.save()
            print("Album updated successfully.")
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "AlbumUpdated"), object: nil)
            navigationController?.popViewController(animated: true) // Dismiss the view controller

            // Dismiss the current view controller
            dismiss(animated: true) {
                // After dismissal, trigger a refresh of the ShowAllAlbumsController
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
            }
        } catch let error as NSError {
            print("Error updating album: \(error.localizedDescription)")
        }
    }


       // Function to display songs associated with the selected album
       func displayAlbumSongs() {
           guard let selectedAlbum = selectedAlbum else { return }

           if let songs = selectedAlbum.songs?.allObjects as? [Song] {
               var yOffset: CGFloat = 20 // Initial Y offset
               let buttonWidth: CGFloat = albumSongsScrollView.frame.width - 40 // Adjust width as needed

               for song in songs {
                   // Create button for each song
                   let button = UIButton(type: .system)
                   button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 30)
                   button.setTitle("\(song.title ?? "")", for: .normal)
                   button.setTitleColor(.black, for: .normal)
                   button.backgroundColor = .lightGray
                   button.layer.cornerRadius = 5

                   // Set accessibility identifier to song ID
                   button.accessibilityIdentifier = "\(song.objectID)"

                   // Add button to scroll view
                   albumSongsScrollView.addSubview(button)

                   // Update Y offset for the next button
                   yOffset += 40 // Adjust spacing as needed
               }

               // Set content size of scroll view based on the total height of buttons
               albumSongsScrollView.contentSize = CGSize(width: albumSongsScrollView.frame.width, height: yOffset)
           }
       }
}
