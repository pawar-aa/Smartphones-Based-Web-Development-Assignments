
import UIKit
import CoreData

class ShowAllAlbumsViewController: UIViewController, UISearchBarDelegate {
    @IBOutlet weak var albumScrollView: UIScrollView!
       @IBOutlet weak var albumSearchBar: UISearchBar!

       var albums = [Album]()
       let managedObjectContext: NSManagedObjectContext = {
           let appDelegate = UIApplication.shared.delegate as! AppDelegate
           return appDelegate.persistentContainer.viewContext
       }()

       override func viewDidLoad() {
           super.viewDidLoad()

           // Register to observe notification for refreshing albums
           NotificationCenter.default.addObserver(self, selector: #selector(refreshAlbums), name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
           NotificationCenter.default.addObserver(self, selector: #selector(refreshAlbums), name: NSNotification.Name(rawValue: "AlbumDeleted"), object: nil)
           NotificationCenter.default.addObserver(self, selector: #selector(refreshAlbums), name: NSNotification.Name(rawValue: "AlbumUpdated"), object: nil)

           albumSearchBar.delegate = self
           fetchAlbums()  // Ensure that albums are fetched before creating buttons
           createAlbumButtons()  // Create buttons after fetching albums
           
           for album in albums {
               print("Album Id: \(album.id) Name: \(album.title)")
           }
       }

       @objc func refreshAlbums() {
           // Refresh album buttons
           fetchAlbums()
           createAlbumButtons()
       }

       // Fetch albums from Core Data
       func fetchAlbums() {
           let fetchRequest: NSFetchRequest<Album> = Album.fetchRequest()

           do {
               albums = try managedObjectContext.fetch(fetchRequest)
           } catch let error as NSError {
               print("Error fetching albums: \(error.localizedDescription)")
           }
       }

    // Method to create album buttons
    func createAlbumButtons() {
        // Remove existing buttons from the scroll view
        albumScrollView.subviews.forEach { $0.removeFromSuperview() }

        // Initial Y offset and button width
        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = albumScrollView.frame.width - 40

        // Filter albums based on search text
        let searchText = albumSearchBar.text ?? ""
        let filteredAlbums = searchText.isEmpty ? albums : albums.filter { $0.title?.lowercased().contains(searchText.lowercased()) ?? false }

        for album in filteredAlbums {
            // Create container view
            let containerView = UIView(frame: CGRect(x: 20, y: yOffset, width: buttonWidth, height: 100))
            containerView.backgroundColor = .black
            containerView.layer.cornerRadius = 5

            // Add album image
            if let imageData = album.image, let albumImage = UIImage(data: imageData) {
                let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 80, height: 80))
                imageView.image = albumImage
                imageView.contentMode = .scaleAspectFill
                imageView.layer.cornerRadius = 5
                imageView.clipsToBounds = true
                containerView.addSubview(imageView)
            }

            // Add album title
            let titleLabel = UILabel(frame: CGRect(x: 100, y: 10, width: buttonWidth - 120, height: 30))
            titleLabel.text = album.title
            titleLabel.font = UIFont.boldSystemFont(ofSize: 16)
            titleLabel.textColor = .white
            containerView.addSubview(titleLabel)

            // Add album artist
            let artistLabel = UILabel(frame: CGRect(x: 100, y: 40, width: buttonWidth - 120, height: 20))
            artistLabel.text = album.artist?.name ?? ""
            artistLabel.font = UIFont.systemFont(ofSize: 14)
            artistLabel.textColor = .lightGray
            containerView.addSubview(artistLabel)

            // Add album release year
            let releaseYearLabel = UILabel(frame: CGRect(x: 100, y: 60, width: buttonWidth - 120, height: 20))
            if let releaseDate = album.releaseDate {
                releaseYearLabel.text = "Released: \(releaseDate)"
            } else {
                releaseYearLabel.text = "Released: N/A"
            }
            releaseYearLabel.font = UIFont.systemFont(ofSize: 14)
            releaseYearLabel.textColor = .lightGray
            containerView.addSubview(releaseYearLabel)

            // Set accessibility identifier to album ID
            containerView.accessibilityIdentifier = "\(album.id)"

            // Add gesture recognizer to containerView
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(albumButtonTapped(_:)))
            containerView.addGestureRecognizer(tapGesture)
            containerView.isUserInteractionEnabled = true

            // Add container view to scroll view
            albumScrollView.addSubview(containerView)

            // Update Y offset for the next button
            yOffset += 120 // Adjust spacing as needed
        }

        // Set content size of scroll view based on the total height of buttons
        albumScrollView.contentSize = CGSize(width: albumScrollView.frame.width, height: yOffset)
    }


       // Implement UISearchBarDelegate method for search functionality
       func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
           // Reload album buttons with filtered albums based on search text
           createAlbumButtons()
       }

    @objc func albumButtonTapped(_ sender: UITapGestureRecognizer) {
        if let containerView = sender.view,
           let albumIDString = containerView.accessibilityIdentifier,
           let albumID = Int(albumIDString),
           let album = albums.first(where: { $0.id == albumID }) {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil) // Assuming your storyboard name is "Main"
            if let showAlbumDetailsViewController = storyboard.instantiateViewController(withIdentifier: "ShowAlbumDetailsViewController") as? ShowAlbumDetailsViewController {
                showAlbumDetailsViewController.selectedAlbum = album
                self.navigationController?.pushViewController(showAlbumDetailsViewController, animated: true)
            }
        }
    }

}
