
import UIKit
import CoreData

class ShowSongDetailsViewController: UIViewController {

    var selectedSong: Song? // Property to hold the selected song
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var durationTextField: UITextField!
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var albumTextField: UITextField!
    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var favouritesSwitch: UISwitch!
    @IBOutlet weak var songImageView: UIImageView!
    
    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let song = selectedSong {
            // Update UI with song details
            titleTextField.text = song.title
            durationTextField.text = "\(song.duration)"
            favouritesSwitch.isOn = song.favorite
            
            // Fetch additional details such as artist name, album title, and genre name based on song's relationships and update UI accordingly
            if let artist = song.artist {
                artistTextField.text = artist.name
            }
            if let album = song.album {
                albumTextField.text = album.title
            }
            if let genre = song.genre {
                genreTextField.text = genre.name
            }
            if let songImage = song.image,  let songImage = UIImage(data: songImage){
                songImageView.image = songImage
            }
            
            titleTextField.isUserInteractionEnabled = true
            durationTextField.isUserInteractionEnabled = true
            genreTextField.isUserInteractionEnabled = false
            albumTextField.isUserInteractionEnabled = false
            artistTextField.isUserInteractionEnabled = false
        }
    }
    
    @IBAction func deleteSongButton(_ sender: UIButton) {
        guard let selectedSong = selectedSong else {
               print("No song selected.")
               return
           }
           
           managedObjectContext.delete(selectedSong)
           
           do {
               try managedObjectContext.save()
               print("Song deleted successfully.")
               NotificationCenter.default.post(name: NSNotification.Name(rawValue: "SongDeleted"), object: nil)
               navigationController?.popViewController(animated: true) // Dismiss the view controller
           } catch let error as NSError {
               print("Error deleting song: \(error), \(error.userInfo)")
           }
    }
    
    @IBAction func updateSongButton(_ sender: Any) {
        guard let selectedSong = selectedSong else {
                print("No song selected.")
                return
            }
            
            // Update song details with values from text fields
            if let newTitle = titleTextField.text {
                selectedSong.title = newTitle
            }
            if let newDurationText = durationTextField.text, let newDuration = Double(newDurationText) {
                selectedSong.duration = newDuration
            }
            
            // Update favorites field
            selectedSong.favorite = favouritesSwitch.isOn
            
            do {
                try managedObjectContext.save()
                print("Song updated successfully.")
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "SongUpdated"), object: nil)
                navigationController?.popViewController(animated: true) // Dismiss the view controller
            } catch let error as NSError {
                print("Could not update song. \(error), \(error.userInfo)")
            }
    }
}
