import UIKit
import CoreData

class MainMenuViewController: UIViewController {

    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    @IBAction func ahowAllSongsButton(_ sender: UIButton) {
    }

    @IBAction func showAllArtistsButton(_ sender: UIButton) {
    }

    @IBAction func showAllAlbumsButton(_ sender: Any) {
    }

    @IBAction func showAllGenreButton(_ sender: Any) {
    }
    @IBAction func clearBtn(_ sender: Any) {
        clearArtistCoreDataEntities()
        clearAlbumCoreDataEntities()
    }

    func clearArtistCoreDataEntities() {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "Artist")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            try managedObjectContext.execute(batchDeleteRequest)
        } catch {
            print("Error clearing Core Data entities: \(error)")
        }
    }
    
    func clearAlbumCoreDataEntities() {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "Album")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            try managedObjectContext.execute(batchDeleteRequest)
        } catch {
            print("Error clearing Core Data entities: \(error)")
        }
    }


    
    @IBAction func fetchAPIData2(_ sender: Any) {
        fetchAlbumsFromAPI()
    }
    @IBAction func fetchAPIData() {
        fetchArtistsFromAPI()
    }

    func fetchArtistsFromAPI() {
        guard let url = URL(string: "https://65feee10b2a18489b386c2a6.mockapi.io/artist") else {
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                return
            }

            guard let data = data else {
                print("No data received")
                return
            }

            do {
                guard let jsonArray = try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]] else {
                    print("Failed to parse JSON")
                    return
                }

                for artistDict in jsonArray {
                    if let id = artistDict["id"] as? String,
                       let name = artistDict["name"] as? String,
                       let image = artistDict["image"] as? String {
                        self.createArtist(artistID: id, name: name, imageURL: image)
                    } else {
                        print("Invalid artist data")
                    }
                }
            } catch {
                print("Error decoding JSON: \(error)")
            }
        }

        task.resume()
    }

    func fetchAlbumsFromAPI() {
        guard let url = URL(string: "https://65feee10b2a18489b386c2a6.mockapi.io/album") else {
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                return
            }

            guard let data = data else {
                print("No data received")
                return
            }

            do {
                guard let jsonArray = try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]] else {
                    print("Failed to parse JSON")
                    return
                }

                for albumDict in jsonArray {
                    if let id = albumDict["id"] as? String,
                       let artistID = albumDict["artist_id"] as? String,
                       let title = albumDict["title"] as? String,
                       let releaseDate = albumDict["released_date"] as? String {
                        
                        guard let album_id = Int16(id) else {
                               return
                           }
                        
                        guard let artist_id = Int16(artistID) else {
                            return
                        }
                                             
                        self.createAlbumf(albumID: album_id, albumTitle: title, artist: self.fetchArtist(withID: artist_id)!,releaseDate: releaseDate, imageURL: "https://logowik.com/content/uploads/images/t-series3119.logowik.com.webp")
                    } else {
                        print("Invalid album data")
                    }
                }
            } catch {
                print("Error decoding JSON: \(error)")
            }
        }

        task.resume()
    }

    func createArtist(artistID: String, name: String, imageURL: String) {
        guard let imageURL = URL(string: imageURL), let imageData = try? Data(contentsOf: imageURL), let image = UIImage(data: imageData) else {
            return
        }

        let artistEntity = NSEntityDescription.entity(forEntityName: "Artist", in: managedObjectContext)!
        let newArtist = NSManagedObject(entity: artistEntity, insertInto: managedObjectContext) as! Artist

        guard let id = Int16(artistID) else {
               return
           }

        newArtist.id = id
        newArtist.name = name
        newArtist.image = imageData

        do {
            try managedObjectContext.save()
        } catch {
            print("Error saving artist: \(error)")
        }
    }

    func createAlbumf(albumID: Int16, albumTitle: String, artist: Artist, releaseDate: String, imageURL: String?) {
        let newAlbum = Album(context: managedObjectContext)
        newAlbum.id = albumID
        newAlbum.title = albumTitle
        newAlbum.artist = artist // Assigning the Artist object directly

        newAlbum.releaseDate = releaseDate

        if let imageURL = imageURL, let imageData = try? Data(contentsOf: URL(string: imageURL)!), let image = UIImage(data: imageData) {
            newAlbum.image = imageData
        }

        do {
            try managedObjectContext.save()
        } catch let error as NSError {
            print("Error saving album: \(error.localizedDescription)")
        }
    }
    
    func fetchArtist(withID artistID: Int16) -> Artist? {
        let fetchRequest: NSFetchRequest<Artist> = Artist.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %d", artistID)
        
        do {
            let artists = try managedObjectContext.fetch(fetchRequest)
            return artists.first
        } catch {
            print("Error fetching artist with ID \(artistID): \(error.localizedDescription)")
            return nil
        }
    }


}
