import UIKit
import CoreData

class GenreDetailsViewController: UIViewController {

    @IBOutlet weak var genreSongsScrollView: UIScrollView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var genreImageView: UIImageView!
    
    var selectedGenre: Genre?
    
    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let genre = selectedGenre {
            print("Genre ID: \(genre.id), Genre Name: \(genre.name ?? "")")
            nameTextField.text = genre.name
            if let imageData = genre.image, let image = UIImage(data: imageData) {
                genreImageView.image = image
            }
            displayGenreSongs()
        }
    }
    
    @IBAction func deleteGenreButton(_ sender: UIButton) {
        guard let selectedGenre = selectedGenre else {
            print("No genre selected.")
            return
        }
        
        let songsFetchRequest: NSFetchRequest<Song> = Song.fetchRequest()
        songsFetchRequest.predicate = NSPredicate(format: "genre == %@", selectedGenre)
        
        do {
            let genreSongs = try managedObjectContext.fetch(songsFetchRequest)
            if !genreSongs.isEmpty {
                let alert = UIAlertController(title: "Cannot Delete Genre", message: "Genre cannot be deleted because it has one or more songs", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else {
                managedObjectContext.delete(selectedGenre)
                try managedObjectContext.save()
                print("Genre deleted successfully.")
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "GenreDeleted"), object: nil)
                navigationController?.popViewController(animated: true) // Dismiss the view controller
            }
        } catch let error as NSError {
            print("Error deleting genre: \(error), \(error.userInfo)")
        }
    }
    
    @IBAction func updateGenreButton(_ sender: UIButton) {
        guard var selectedGenre = selectedGenre else {
            print("No genre selected.")
            return
        }
        
        if let newName = nameTextField.text {
            selectedGenre.name = newName
        }
        
        do {
            try managedObjectContext.save()
            print("Genre updated successfully.")
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "GenreUpdated"), object: nil)
            navigationController?.popViewController(animated: true) // Dismiss the view controller
        } catch let error as NSError {
            print("Could not update genre. \(error), \(error.userInfo)")
        }
    }
    
    func displayGenreSongs() {
        guard let selectedGenre = selectedGenre else { return }
        
        let songsFetchRequest: NSFetchRequest<Song> = Song.fetchRequest()
        songsFetchRequest.predicate = NSPredicate(format: "genre == %@", selectedGenre)
        
        do {
            let genreSongs = try managedObjectContext.fetch(songsFetchRequest)
            var yOffset: CGFloat = 20
            let buttonWidth: CGFloat = genreSongsScrollView.frame.width - 40
            
            for song in genreSongs {
                let button = UIButton(type: .system)
                button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 30)
                button.setTitle(song.title, for: .normal)
                button.setTitleColor(.black, for: .normal)
                button.backgroundColor = .lightGray
                button.layer.cornerRadius = 5
                
                button.accessibilityIdentifier = song.objectID.uriRepresentation().absoluteString
                
                genreSongsScrollView.addSubview(button)
                
                yOffset += 40
            }
            
            genreSongsScrollView.contentSize = CGSize(width: genreSongsScrollView.frame.width, height: yOffset)
        } catch let error as NSError {
            print("Could not fetch songs. \(error), \(error.userInfo)")
        }
    }
}
