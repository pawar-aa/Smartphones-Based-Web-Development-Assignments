import UIKit

class ShowArtistDetailsController: UIViewController {

    @IBOutlet weak var artistsSongsScrollView: UIScrollView!
    @IBOutlet weak var nameTextField: UITextField!
    
    var selectedArtist: ArtistsData?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let artist = selectedArtist {
            nameTextField.text = artist.name
            
            displayArtistSongs()
        }
    }
    
    @IBAction func artistDetailsBackButton(_ sender: UIButton) {
        selectedArtist = nil
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func deleteArtistButton(_ sender: UIButton) {
        guard let selectedArtist = selectedArtist else {
            print("No artist selected.")
            return
        }
        
        if let artistAlbums = CoreDataManager.shared.getAllAlbums()?.filter({ $0.artistID == Int(selectedArtist.id) }) {
            if artistAlbums.isEmpty {
                let context = CoreDataManager.shared.persistentContainer.viewContext
                context.delete(selectedArtist)
                CoreDataManager.shared.saveContext()
                
                dismiss(animated: true) {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
                }
            } else {
                let alert = UIAlertController(title: "Cannot Delete Artist", message: "Artist cannot be deleted because it has one or more Albums", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        } else {
            print("Failed to fetch albums associated with the artist.")
        }
    }

    @IBAction func updateArtistButton(_ sender: UIButton) {
        guard let selectedArtist = selectedArtist else {
            print("No artist selected.")
            return
        }
        
        if let newName = nameTextField.text {
            selectedArtist.name = newName
        }
        
        CoreDataManager.shared.saveContext()
        print("Artist updated successfully.")
        
        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
        }
    }
    
    func displayArtistSongs() {
        guard let selectedArtist = selectedArtist else { return }
        
        var artistSongs = [SongsData]()
        
        if let allSongs = CoreDataManager.shared.getAllSongs() {
            artistSongs = allSongs.filter { $0.artistID == Int(selectedArtist.id) }
        } else {
            print("Failed to fetch songs.")
            return
        }

        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = artistsSongsScrollView.frame.width - 40
        
        for song in artistSongs {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
            if let title = song.title {
                button.setTitle(title, for: .normal)
            } else {
                button.setTitle("Unknown Title", for: .normal)
            }

            button.setTitleColor(.white, for: .normal)
            button.backgroundColor = .black
            button.layer.cornerRadius = 5
            button.contentHorizontalAlignment = .left
            button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
            
            button.accessibilityIdentifier = "\(song.id)"
            
            artistsSongsScrollView.addSubview(button)
            
            yOffset += 80
        }
        
        artistsSongsScrollView.contentSize = CGSize(width: artistsSongsScrollView.frame.width, height: yOffset)
    }

}
