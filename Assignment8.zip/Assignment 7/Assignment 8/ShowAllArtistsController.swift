import UIKit

class ShowAllArtistsController: UIViewController, UISearchBarDelegate {

    @IBOutlet weak var artistsScrollView: UIScrollView!
    @IBOutlet weak var artistSearchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(refreshArtists), name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
        artistSearchBar.delegate = self
        createArtistButtons()
    }
    
    @objc func refreshArtists() {
        createArtistButtons()
    }
    
    @IBAction func showAllArtistsBackButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addArtists(_ sender: UIButton) {
        let createArtistsVC = CreateArtistController(nibName: "CreateArtist", bundle: nil)
        createArtistsVC.modalPresentationStyle = .fullScreen
        createArtistsVC.modalTransitionStyle = .crossDissolve
        self.present(createArtistsVC, animated: true)
    }
    
    func createArtistButtons() {
        artistsScrollView.subviews.forEach { $0.removeFromSuperview() }

        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = artistsScrollView.frame.width - 40

        let filteredArtists: [ArtistsData]
        
        if var allArtists = CoreDataManager.shared.getAllArtists() {
            if let searchText = artistSearchBar.text, !searchText.isEmpty {
                allArtists = allArtists.filter { $0.name?.lowercased().contains(searchText.lowercased()) ?? false }
            }
            filteredArtists = allArtists
        } else {
            filteredArtists = []
        }

        for artist in filteredArtists {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
            if let artistName = artist.name {
                button.setTitle(artistName, for: .normal)
            } else {
                button.setTitle("Unknown Artist", for: .normal)
            }
            button.setTitleColor(.white, for: .normal)
            button.addTarget(self, action: #selector(artistButtonTapped(_:)), for: .touchUpInside)
            button.backgroundColor = .black
            button.layer.cornerRadius = 5
            button.contentHorizontalAlignment = .left
            button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)

            button.accessibilityIdentifier = "\(artist.id)"

            artistsScrollView.addSubview(button)

            yOffset += 80
        }

        artistsScrollView.contentSize = CGSize(width: artistsScrollView.frame.width, height: yOffset)
    }

    @objc func artistButtonTapped(_ sender: UIButton) {
        if let artistIDString = sender.accessibilityIdentifier, let artistID = Int(artistIDString) {
            if let selectedArtist = CoreDataManager.shared.getArtistByID(artistID) {
                let showArtistDetails = ShowArtistDetailsController(nibName: "ShowArtistDetails", bundle: nil)
                showArtistDetails.modalPresentationStyle = .fullScreen
                showArtistDetails.modalTransitionStyle = .crossDissolve
                showArtistDetails.selectedArtist = selectedArtist
                self.present(showArtistDetails, animated: true)
            }
        }
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        createArtistButtons()
    }
}
