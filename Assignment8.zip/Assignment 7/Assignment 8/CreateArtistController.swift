import UIKit

class CreateArtistController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func createArtistBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func createArtistButton(_ sender: UIButton) {
        guard let name = nameTextField.text, !name.isEmpty else {
            showAlert(message: "Please enter artist name.")
            return
        }

        if let existingArtists = CoreDataManager.shared.getAllArtists() {
            if existingArtists.first(where: { $0.name == name }) == nil {
                let lastArtistID = existingArtists.map({ $0.id }).max() ?? 0
                let newArtistID = lastArtistID + 1
                
                let newArtist = ArtistsData(context: CoreDataManager.shared.persistentContainer.viewContext)
                newArtist.id = Int16(newArtistID)
                newArtist.name = name
                
                CoreDataManager.shared.saveContext()
                
                dismiss(animated: true) {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
                }
            } else {
                showAlert(message: "Artist with this name already exists.")
            }
        } else {
            showAlert(message: "Failed to fetch artists.")
        }
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

}
