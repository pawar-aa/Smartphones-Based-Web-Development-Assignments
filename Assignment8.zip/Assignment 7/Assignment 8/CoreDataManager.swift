import Foundation
import CoreData

class CoreDataManager {
    static let shared = CoreDataManager()
    
    private init() {}
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MusicModel")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    func getAllSongs() -> [SongsData]? {
        let managedContext = persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<SongsData> = SongsData.fetchRequest()
        
        do {
            let songs = try managedContext.fetch(fetchRequest)
            return songs
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }
    
    func getAllArtists() -> [ArtistsData]? {
        let managedContext = persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<ArtistsData> = ArtistsData.fetchRequest()
        
        do {
            let artists = try managedContext.fetch(fetchRequest)
            return artists
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }
    
    func getAllAlbums() -> [AlbumsData]? {
        let managedContext = persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<AlbumsData> = AlbumsData.fetchRequest()
        
        do {
            let albums = try managedContext.fetch(fetchRequest)
            return albums
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }
    
    func getAllGenres() -> [GenresData]? {
        let managedContext = persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<GenresData> = GenresData.fetchRequest()
        
        do {
            let genres = try managedContext.fetch(fetchRequest)
            return genres
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }
    
    func saveContext() {
            let context = persistentContainer.viewContext
            if context.hasChanges {
                do {
                    try context.save()
                } catch {
                    let nserror = error as NSError
                    fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
                }
            }
    }
    
    func getSongByID(_ id: Int) -> SongsData? {
        if let allSongs = CoreDataManager.shared.getAllSongs() {
            return allSongs.first(where: { $0.id == id })
        }
        return nil
    }
    
    func getArtistByID(_ id: Int) -> ArtistsData? {
        if let allArtists = CoreDataManager.shared.getAllArtists() {
            return allArtists.first(where: { $0.id == id })
        }
        return nil
    }
    
    func getAlbumByID(_ id: Int) -> AlbumsData? {
        if let allAlbums = CoreDataManager.shared.getAllAlbums() {
            return allAlbums.first(where: { $0.id == id })
        }
        return nil
    }
    
    func getGenreByID(_ id: Int) -> GenresData? {
        if let allGenres = CoreDataManager.shared.getAllGenres() {
            return allGenres.first(where: { $0.id == id })
        }
        return nil
    }
    
    func fetchArtists() -> [ArtistsData]? {
            let fetchRequest: NSFetchRequest<ArtistsData> = ArtistsData.fetchRequest()
            do {
                let artists = try persistentContainer.viewContext.fetch(fetchRequest)
                return artists
            } catch {
                print("Error fetching artists: \(error.localizedDescription)")
                return nil
            }
        }

    func fetchAlbums() -> [AlbumsData]? {
        let fetchRequest: NSFetchRequest<AlbumsData> = AlbumsData.fetchRequest()
        do {
            let albums = try persistentContainer.viewContext.fetch(fetchRequest)
            return albums
        } catch {
            print("Error fetching albums: \(error.localizedDescription)")
            return nil
        }
    }

    func fetchGenres() -> [GenresData]? {
        let fetchRequest: NSFetchRequest<GenresData> = GenresData.fetchRequest()
        do {
            let genres = try persistentContainer.viewContext.fetch(fetchRequest)
            return genres
        } catch {
            print("Error fetching genres: \(error.localizedDescription)")
            return nil
        }
    }
}
