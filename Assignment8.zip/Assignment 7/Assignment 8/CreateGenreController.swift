import UIKit
import CoreData

class CreateGenreController: UIViewController {

    @IBOutlet weak var genreNameTextField: UITextField!
    
    var genresData: [GenresData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchGenres()
    }

    func fetchGenres() {
        if let fetchedGenres = CoreDataManager.shared.fetchGenres() {
            genresData = fetchedGenres
        }
    }

    @IBAction func createGenreBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func createGenreButton(_ sender: UIButton) {
        guard let name = genreNameTextField.text, !name.isEmpty else {
            showAlert(message: "Please enter genre name.")
            return
        }
        
        guard let lastGenreID = genresData.map({ $0.id }).max() else {
            showAlert(message: "Unable to find the last genre ID.")
            return
        }
        
        let newGenre = GenresData(context: CoreDataManager.shared.persistentContainer.viewContext)
        newGenre.id = lastGenreID + 1
        newGenre.name = name
        
        CoreDataManager.shared.saveContext()
        
        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshGenres"), object: nil)
        }
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
