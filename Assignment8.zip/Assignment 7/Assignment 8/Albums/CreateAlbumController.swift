import UIKit
import CoreData

class CreateAlbumController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var albumTitleTextField: UITextField!
    @IBOutlet weak var releaseDateTextField: UITextField!
    
    var artistsData: [ArtistsData] = []
    var artistPickerView = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        artistPickerView.delegate = self
        artistPickerView.dataSource = self
        artistTextField.inputView = artistPickerView
        artistTextField.placeholder = "Select Artist"

        fetchArtists()
    }

    func fetchArtists() {
        if let fetchedArtists = CoreDataManager.shared.fetchArtists() {
            artistsData = fetchedArtists
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return artistsData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return artistsData[row].name
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        artistTextField.text = artistsData[row].name
    }

    @IBAction func createAlbumButton(_ sender: UIButton) {
        guard let artistName = artistTextField.text, !artistName.isEmpty else {
            showAlert(message: "Please select an artist.")
            return
        }
        
        guard let artistID = artistsData.first(where: { $0.name == artistName })?.id else {
            showAlert(message: "Selected artist not found.")
            return
        }
        
        guard let albumTitle = albumTitleTextField.text, !albumTitle.isEmpty else {
            showAlert(message: "Please enter album title.")
            return
        }
        
        guard let releaseDate = releaseDateTextField.text, !releaseDate.isEmpty else {
            showAlert(message: "Please enter release date.")
            return
        }

        if !releaseDate.isValidDateFormat() {
            showAlert(message: "Invalid date format. Please use the format DD/MM/YYYY.")
            return
        }
        

        guard let existingAlbumIDs = CoreDataManager.shared.getAllAlbums()?.map({ Int($0.id) }) else {
            print("Error: existingAlbumIDs is nil")
            return
        }

        let maxAlbumID = existingAlbumIDs.max() ?? 0
        let newAlbumID = maxAlbumID + 1

        let newAlbum = AlbumsData(context: CoreDataManager.shared.persistentContainer.viewContext)
        newAlbum.id = Int16(newAlbumID)
        newAlbum.artistID = artistID
        newAlbum.title = albumTitle
        newAlbum.releaseDate = releaseDate


        CoreDataManager.shared.saveContext()
        
        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
        }
    }
    
    @IBAction func createAlbumBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

extension String {
    func isValidDateFormat() -> Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        return dateFormatter.date(from: self) != nil
    }
}
