import UIKit

class ShowAllAlbumsController: UIViewController, UISearchBarDelegate {

    @IBAction func addNewAlbumButton(_ sender: UIButton) {
        let createNewAlbum = CreateAlbumController(nibName: "CreateAlbum", bundle: nil)
        createNewAlbum.modalPresentationStyle = .fullScreen
        createNewAlbum.modalTransitionStyle = .crossDissolve
        self.present(createNewAlbum, animated: true)
    }
    
    @IBAction func albumBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var albumScrollView: UIScrollView!
    @IBOutlet weak var albumSearchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(refreshAlbums), name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)

            albumSearchBar.delegate = self
            createAlbumButtons()
    }
    @objc func refreshAlbums() {
        createAlbumButtons()
    }
    
    func createAlbumButtons() {
        albumScrollView.subviews.forEach { $0.removeFromSuperview() }

        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = albumScrollView.frame.width - 40

        var filteredAlbums: [AlbumsData] = []

        if let allAlbums = CoreDataManager.shared.getAllAlbums() {
            if let searchText = albumSearchBar.text, !searchText.isEmpty {
                filteredAlbums = allAlbums.filter { $0.title?.lowercased().contains(searchText.lowercased()) ?? false }
            } else {
                filteredAlbums = allAlbums
            }
        }

        for album in filteredAlbums {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
            if let albumName = album.title {
                button.setTitle(albumName, for: .normal)
            } else {
                button.setTitle("Unknown Album", for: .normal)
            }
            button.setTitleColor(.white, for: .normal)
            button.addTarget(self, action: #selector(albumButtonTapped(_:)), for: .touchUpInside)
            button.backgroundColor = .black
            button.layer.cornerRadius = 5
            button.contentHorizontalAlignment = .left
            button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)

            button.accessibilityIdentifier = "\(album.id)"

            albumScrollView.addSubview(button)

            yOffset += 80
        }

        albumScrollView.contentSize = CGSize(width: albumScrollView.frame.width, height: yOffset)
    }


    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        createAlbumButtons()
    }
    
    @objc func albumButtonTapped(_ sender: UIButton) {
        if let albumIDString = sender.accessibilityIdentifier, let albumID = Int(albumIDString) {
            if let selectedAlbum = CoreDataManager.shared.getAlbumByID(albumID) {
                let showAlbumDetails = ShowAlbumDetailsController(nibName: "ShowAlbumDetails", bundle: nil)
                showAlbumDetails.modalPresentationStyle = .fullScreen
                showAlbumDetails.modalTransitionStyle = .crossDissolve
                showAlbumDetails.selectedAlbum = selectedAlbum
                self.present(showAlbumDetails, animated: true)
            }
        }
    }
}
