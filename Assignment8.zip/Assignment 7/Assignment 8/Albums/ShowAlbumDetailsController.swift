import UIKit

class ShowAlbumDetailsController: UIViewController {

    @IBOutlet weak var albumReleaseDateTextField: UITextField!
    @IBOutlet weak var albumArtistTextField: UITextField!
    @IBOutlet weak var albumTitleTextField: UITextField!
    @IBOutlet weak var albumSongsScrollView: UIScrollView!
    
    var selectedAlbum: AlbumsData?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let album = selectedAlbum {
            albumTitleTextField.text = album.title
            albumReleaseDateTextField.text = album.releaseDate
            
            if let fetchedArtists = CoreDataManager.shared.getAllArtists() {
                if let artist = fetchedArtists.first(where: { $0.id == Int(album.artistID) }) {
                    albumArtistTextField.text = artist.name
                }
            } else {
                print("Failed to fetch artists.")
            }
            
            displayAlbumSongs()
        }
        
        albumArtistTextField.isUserInteractionEnabled = false
    }

    
    @IBAction func albumDetailsBackButton(_ sender: UIButton) {
        selectedAlbum = nil
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func albumDeleteButton(_ sender: UIButton) {
        guard let selectedAlbum = selectedAlbum else {
            print("No album selected.")
            return
        }

        if let allSongs = CoreDataManager.shared.getAllSongs() {
            let albumHasSongs = allSongs.contains { $0.albumID == Int(selectedAlbum.id) }

            if albumHasSongs {
                let alert = UIAlertController(title: "Cannot Delete Album", message: "Album cannot be deleted because it has 1 or more Songs", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else {
                let context = CoreDataManager.shared.persistentContainer.viewContext
                context.delete(selectedAlbum)
                CoreDataManager.shared.saveContext()
                
                dismiss(animated: true) {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
                }
            }
        } else {
            print("Failed to fetch songs.")
        }
    }

    
    @IBAction func updateAlbumButton(_ sender: UIButton) {
        guard let selectedAlbum = selectedAlbum else {
            print("No album selected.")
            return
        }

        guard let newReleaseDate = albumReleaseDateTextField.text, isValidReleaseDate(newReleaseDate) else {
            showAlert(message: "Release date should be in DD/MM/YYYY format.")
            return
        }

        if let newTitle = albumTitleTextField.text {
            selectedAlbum.title = newTitle
        }
        selectedAlbum.releaseDate = newReleaseDate

        CoreDataManager.shared.saveContext()

        print("Album updated successfully.")

        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
        }
    }

    func isValidReleaseDate(_ releaseDate: String) -> Bool {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.date(from: releaseDate) != nil
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func displayAlbumSongs() {
        guard let selectedAlbum = selectedAlbum else { return }

        if let allSongs = CoreDataManager.shared.getAllSongs() {
            let albumSongs = allSongs.filter { $0.albumID == Int(selectedAlbum.id) }

            var yOffset: CGFloat = 20
            let buttonWidth: CGFloat = albumSongsScrollView.frame.width - 40

            for song in albumSongs {
                let button = UIButton(type: .system)
                button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
                if let songTitle = song.title {
                    button.setTitle(songTitle, for: .normal)
                } else {
                    button.setTitle("Unknown Song", for: .normal)
                }
                button.setTitleColor(.white, for: .normal)
                button.backgroundColor = .black
                button.layer.cornerRadius = 5
                button.contentHorizontalAlignment = .left
                button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
                button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)

                button.accessibilityIdentifier = "\(song.id)"

                albumSongsScrollView.addSubview(button)

                yOffset += 80
            }

            albumSongsScrollView.contentSize = CGSize(width: albumSongsScrollView.frame.width, height: yOffset)
        } else {
            print("Failed to fetch songs.")
        }
    }
}
