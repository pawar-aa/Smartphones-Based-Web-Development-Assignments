import UIKit

class ShowSongDetailsController: UIViewController {
    var selectedSong: SongsData?

    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var durationTextFild: UITextField!
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var albumTextField: UITextField!
    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var favouritesSwitch: UISwitch!

    @IBAction func deleteSongButton(_ sender: UIButton) {
        guard let selectedSong = selectedSong else {
            print("No song selected.")
            return
        }

        CoreDataManager.shared.persistentContainer.viewContext.delete(selectedSong)
        CoreDataManager.shared.saveContext()

        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
        }
    }

    @IBAction func updateSongButton(_ sender: Any) {
        guard let selectedSong = selectedSong else {
            print("No song selected.")
            return
        }

        if let newTitle = titleTextField.text {
            selectedSong.title = newTitle
        }
        if let newDurationText = durationTextFild.text, let newDuration = Double(newDurationText) {
            selectedSong.duration = newDuration
        }
        selectedSong.favorite = favouritesSwitch.isOn

        CoreDataManager.shared.saveContext()

        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        if let song = selectedSong {
            titleTextField.text = song.title
            durationTextFild.text = "\(song.duration)"

            let genre = CoreDataManager.shared.getAllGenres()?.first(where: { $0.id == song.genreID })
            genreTextField.text = genre?.name

            let album = CoreDataManager.shared.getAllAlbums()?.first(where: { $0.id == song.albumID })
            albumTextField.text = album?.title

            let artist = CoreDataManager.shared.getAllArtists()?.first(where: { $0.id == song.artistID })
            artistTextField.text = artist?.name
            
            favouritesSwitch.isOn = song.favorite

            titleTextField.isUserInteractionEnabled = true
            durationTextFild.isUserInteractionEnabled = true
            genreTextField.isUserInteractionEnabled = false
            albumTextField.isUserInteractionEnabled = false
            artistTextField.isUserInteractionEnabled = false
        }
    }

    @IBAction func songDetailsBackButton(_ sender: UIButton) {
        selectedSong = nil
        dismiss(animated: true, completion: nil)
    }

}
