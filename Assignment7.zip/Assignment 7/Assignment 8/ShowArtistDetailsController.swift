import UIKit

class ShowArtistDetailsController: UIViewController {

    @IBOutlet weak var artistsSongsScrollView: UIScrollView!
    @IBOutlet weak var nameTextField: UITextField!
    
    var selectedArtist: Artist?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let artist = selectedArtist {
            nameTextField.text = artist.name
            
            displayArtistSongs()
        }
    }
    
    @IBAction func artistDetailsBackButton(_ sender: UIButton) {
        selectedArtist = nil
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func deleteArtistButton(_ sender: UIButton) {
        guard let selectedArtist = selectedArtist else {
            print("No artist selected.")
            return
        }
        
        let artistHasAlbums = albums.contains { $0.artistID == selectedArtist.id }
        
        if artistHasAlbums {
            let alert = UIAlertController(title: "Cannot Delete Artist", message: "Artist cannot be deleted because it has 1 or more Albums", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else {
            if let index = artists.firstIndex(where: { $0.id == selectedArtist.id }) {
                artists.remove(at: index)
                print("Artist deleted successfully.")
                
                dismiss(animated: true) {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
                }
            } else {
                print("Failed to delete artist.")
            }
        }
        
    }
    @IBAction func updateArtistButton(_ sender: UIButton) {
        guard var selectedArtist = selectedArtist else {
            print("No artist selected.")
            return
        }
        
        if let newName = nameTextField.text {
            selectedArtist.name = newName
        }
        
        if let index = artists.firstIndex(where: { $0.id == selectedArtist.id }) {
            artists[index] = selectedArtist
        }
        
        print("Artist updated successfully.")
        
        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
        }
    }
    
    func displayArtistSongs() {
        guard let selectedArtist = selectedArtist else { return }
        
        let artistSongs = songs.filter { $0.artistID == selectedArtist.id }
        
        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = artistsSongsScrollView.frame.width - 40
        
        for song in artistSongs {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
            button.setTitle("\(song.title)", for: .normal)
            button.setTitleColor(.white, for: .normal)
            button.backgroundColor = .black
            button.layer.cornerRadius = 5
            button.contentHorizontalAlignment = .left
            button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
            
            button.accessibilityIdentifier = "\(song.id)"
            
            artistsSongsScrollView.addSubview(button)
            
            yOffset += 80
        }
        
        artistsSongsScrollView.contentSize = CGSize(width: artistsSongsScrollView.frame.width, height: yOffset)
    }
}
