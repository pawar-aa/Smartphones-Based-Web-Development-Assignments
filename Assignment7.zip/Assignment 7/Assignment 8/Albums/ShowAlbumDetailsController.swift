import UIKit

class ShowAlbumDetailsController: UIViewController {

    @IBOutlet weak var albumReleaseDateTextField: UITextField!
    @IBOutlet weak var albumArtistTextField: UITextField!
    @IBOutlet weak var albumTitleTextField: UITextField!
    @IBOutlet weak var albumSongsScrollView: UIScrollView!
    
    var selectedAlbum: Album?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let album = selectedAlbum {
            albumTitleTextField.text = album.title
            albumReleaseDateTextField.text = album.releaseDate
            if let artist = artists.first(where: { $0.id == album.artistID }) {
                albumArtistTextField.text = artist.name
            }
            displayAlbumSongs()
        }
        
        albumArtistTextField.isUserInteractionEnabled = false
    }
    
    @IBAction func albumDetailsBackButton(_ sender: UIButton) {
        selectedAlbum = nil
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func albumDeleteButton(_ sender: UIButton) {
        guard let selectedAlbum = selectedAlbum else {
            print("No album selected.")
            return
        }

        let albumHasSongs = songs.contains { $0.albumID == selectedAlbum.id }

        if albumHasSongs {
            let alert = UIAlertController(title: "Cannot Delete Album", message: "Album cannot be deleted because it has 1 or more Songs", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else {
            if let index = albums.firstIndex(where: { $0.id == selectedAlbum.id }) {
                albums.remove(at: index)
                print("Album deleted successfully.")

                dismiss(animated: true) {
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
                    }
            } else {
                print("Failed to delete album.")
            }
        }
    }
    
    @IBAction func updateAlbumButton(_ sender: UIButton) {
        guard var selectedAlbum = selectedAlbum else {
            print("No album selected.")
            return
        }

        if let newTitle = albumTitleTextField.text {
            selectedAlbum.title = newTitle
        }
        if let newReleaseDate = albumReleaseDateTextField.text {
            selectedAlbum.releaseDate = newReleaseDate
        }

        if let index = albums.firstIndex(where: { $0.id == selectedAlbum.id }) {
            albums[index] = selectedAlbum
        }

        print("Album updated successfully.")

        dismiss(animated: true) {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
            }
    }
    
    func displayAlbumSongs() {
        guard let selectedAlbum = selectedAlbum else { return }

        let albumSongs = songs.filter { $0.albumID == selectedAlbum.id }

        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = albumSongsScrollView.frame.width - 40

        for song in albumSongs {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
            button.setTitle("\(song.title)", for: .normal)
            button.setTitleColor(.white, for: .normal)
            button.backgroundColor = .black
            button.layer.cornerRadius = 5
            button.contentHorizontalAlignment = .left
            button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)

            button.accessibilityIdentifier = "\(song.id)"

            albumSongsScrollView.addSubview(button)

            yOffset += 80
        }

        albumSongsScrollView.contentSize = CGSize(width: albumSongsScrollView.frame.width, height: yOffset)
    }
}
