import UIKit

class CreateAlbumController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var albumTitleTextField: UITextField!
    @IBOutlet weak var releaseDateTextField: UITextField!
    
    @IBAction func createAlbumButton(_ sender: UIButton) {
        guard let artistName = artistTextField.text, !artistName.isEmpty else {
            showAlert(message: "Please select an artist.")
            return
        }
        
        guard let artistID = artists.first(where: { $0.name == artistName })?.id else {
            showAlert(message: "Selected artist not found.")
            return
        }
        
        guard let albumTitle = albumTitleTextField.text, !albumTitle.isEmpty else {
            showAlert(message: "Please enter album title.")
            return
        }
        
        guard let releaseDate = releaseDateTextField.text, !releaseDate.isEmpty else {
            showAlert(message: "Please enter release date.")
            return
        }
        
        guard let lastAlbumID = albums.map({ $0.id }).max() else {
            showAlert(message: "Unable to find the last album ID.")
            return
        }
        
        let newAlbum = Album(id: lastAlbumID + 1, artistID: artistID, title: albumTitle, releaseDate: releaseDate)
        albums.append(newAlbum)
        
        dismiss(animated: true) {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
            }
    }
    
    @IBAction func createAlbumBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    var artistPickerView = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        artistPickerView.delegate = self
        artistPickerView.dataSource = self
        artistTextField.inputView = artistPickerView
        artistTextField.placeholder = "Select Artist"
    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return artists.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return artists[row].name
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        artistTextField.text = artists[row].name
    }
}
