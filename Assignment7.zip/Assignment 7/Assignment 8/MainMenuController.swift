import UIKit

class MainMenuController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    @IBAction func showAllSongsButtonn(_ sender: Any) {
        let showAllSongsVC = ShowAllSongsController(nibName: "ShowAllSongs", bundle: nil)
        showAllSongsVC.modalPresentationStyle = .fullScreen
        showAllSongsVC.modalTransitionStyle = .crossDissolve
        self.present(showAllSongsVC, animated: true)
    }
    
    @IBAction func showAllArtistsButton(_ sender: UIButton) {
        let showAllArtistsVC = ShowAllArtistsController(nibName: "ShowAllArtists", bundle: nil)
        showAllArtistsVC.modalPresentationStyle = .fullScreen
        showAllArtistsVC.modalTransitionStyle = .crossDissolve
        self.present(showAllArtistsVC, animated: true)
    }
    
    @IBAction func showAllAlbumsButton(_ sender: Any) {
        let showAllAlbumsVC = ShowAllAlbumsController(nibName: "ShowAllAlbums", bundle: nil)
        showAllAlbumsVC.modalPresentationStyle = .fullScreen
        showAllAlbumsVC.modalTransitionStyle = .crossDissolve
        self.present(showAllAlbumsVC, animated: true)
    }
    
    @IBAction func showAllGenreButton(_ sender: Any) {
        let showAllGenresVC = ShowAllGenreController(nibName: "ShowAllGenre", bundle: nil)
        showAllGenresVC.modalPresentationStyle = .fullScreen
        showAllGenresVC.modalTransitionStyle = .crossDissolve
        self.present(showAllGenresVC, animated: true)
    }
    @IBAction func ExitButton(_ sender: Any) {
        exit(0)
    }
}
