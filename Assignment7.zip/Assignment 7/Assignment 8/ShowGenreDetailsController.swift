import UIKit

class ShowGenreDetailsController: UIViewController {

    @IBOutlet weak var genreSongsScrollView: UIScrollView!
    @IBOutlet weak var genreNameTextField: UITextField!
    
    var selectedGenre: Genre?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let genre = selectedGenre {
            print("Genre ID: \(genre.id)")
            print("Name: \(genre.name)")
            genreNameTextField.text = genre.name
            displayGenreSongs()
        }
    }
    
    @IBAction func genreDetailsBackButton(_ sender: UIButton) {
        selectedGenre = nil
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func genreDetailsDeleteButton(_ sender: UIButton) {
        guard let selectedGenre = selectedGenre else {
            print("No genre selected.")
            return
        }
        
        let genreHasSongs = songs.contains { $0.genreID == selectedGenre.id }
        
        if genreHasSongs {
            let alert = UIAlertController(title: "Cannot Delete Genre", message: "Genre cannot be deleted because it is associated with one or more songs", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else {
            if let index = genres.firstIndex(where: { $0.id == selectedGenre.id }) {
                genres.remove(at: index)
                print("Genre deleted successfully.")
                
                dismiss(animated: true) {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshGenres"), object: nil)
                }
            } else {
                print("Failed to delete genre.")
            }
        }
    }
    
    @IBAction func generaDetailsUpdateButton(_ sender: UIButton) {
        guard var selectedGenre = selectedGenre else {
            print("No genre selected.")
            return
        }
        
        if let newName = genreNameTextField.text {
            selectedGenre.name = newName
        }
        
        if let index = genres.firstIndex(where: { $0.id == selectedGenre.id }) {
            genres[index] = selectedGenre
        }
        
        print("Genre updated successfully.")
        
        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshGenres"), object: nil)
        }
    }
    
    func displayGenreSongs() {
        guard let selectedGenre = selectedGenre else { return }
        
        let genreSongs = songs.filter { $0.genreID == selectedGenre.id }
        
        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = genreSongsScrollView.frame.width - 40
        
        for song in genreSongs {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
            button.setTitle("\(song.title)", for: .normal)
            button.setTitleColor(.white, for: .normal)
            button.backgroundColor = .black
            button.layer.cornerRadius = 5
            button.contentHorizontalAlignment = .left
            button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
            button.accessibilityIdentifier = "\(song.id)"
            genreSongsScrollView.addSubview(button)
            yOffset += 80
        }
        
        genreSongsScrollView.contentSize = CGSize(width: genreSongsScrollView.frame.width, height: yOffset)
    }
}
