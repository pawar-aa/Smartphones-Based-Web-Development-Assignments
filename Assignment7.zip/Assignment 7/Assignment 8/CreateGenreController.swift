import UIKit

class CreateGenreController: UIViewController {

    @IBOutlet weak var genreNameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func createGenreBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func createGenreButton(_ sender: UIButton) {
        guard let name = genreNameTextField.text, !name.isEmpty else {
            showAlert(message: "Please enter genre name.")
            return
        }
        
        guard genres.firstIndex(where: { $0.name == name }) == nil else {
            showAlert(message: "Genre with this name already exists.")
            return
        }
        
        guard let lastGenreID = genres.map({ $0.id }).max() else {
            showAlert(message: "Unable to find the last genre ID.")
            return
        }
        
        let newGenre = Genre(id: lastGenreID + 1, name: name)
        genres.append(newGenre)
        
        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshGenres"), object: nil)
        }
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
