import UIKit

class CreateArtistController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func createArtistBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func createArtistButton(_ sender: UIButton) {
        guard let name = nameTextField.text, !name.isEmpty else {
                    showAlert(message: "Please enter artist name.")
                    return
                }
                
                guard artists.firstIndex(where: { $0.name == name }) == nil else {
                    showAlert(message: "Artist with this name already exists.")
                    return
                }
                
                guard let lastArtistID = artists.map({ $0.id }).max() else {
                    showAlert(message: "Unable to find the last artist ID.")
                    return
                }
                
                let newArtist = Artist(id: lastArtistID + 1, name: name)
                artists.append(newArtist)
                
        dismiss(animated: true) {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
            }
    }
    func showAlert(message: String) {
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }

}
