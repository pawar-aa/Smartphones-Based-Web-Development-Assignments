import UIKit

class ShowAllGenreController: UIViewController, UISearchBarDelegate {

    @IBOutlet weak var genreScrollView: UIScrollView!
    @IBOutlet weak var genreSearchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(refreshGenres), name: NSNotification.Name(rawValue: "RefreshGenres"), object: nil)
        
        genreSearchBar.delegate = self
        createGenreButtons()
    }
    
    @objc func refreshGenres() {
        createGenreButtons()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        createGenreButtons()
    }

    @IBAction func showAllGenreBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addGenreButton(_ sender: UIButton) {
        let createGenreVC = CreateGenreController(nibName: "CreateGenre", bundle: nil)
        createGenreVC.modalPresentationStyle = .fullScreen
        createGenreVC.modalTransitionStyle = .crossDissolve
        self.present(createGenreVC, animated: true)
    }
    
    func createGenreButtons() {
        genreScrollView.subviews.forEach { $0.removeFromSuperview() }

        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = genreScrollView.frame.width - 40
        
        let filteredGenres: [Genre]
        if let searchText = genreSearchBar.text, !searchText.isEmpty {
            filteredGenres = genres.filter { $0.name.lowercased().contains(searchText.lowercased()) }
        } else {
            filteredGenres = genres
        }
        
        for genre in filteredGenres {
            let button = UIButton(type: .system)
            button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
            button.setTitle("\(genre.name)", for: .normal)
            button.setTitleColor(.white, for: .normal)
            button.addTarget(self, action: #selector(genreButtonTapped(_:)), for: .touchUpInside)
            button.backgroundColor = .black
            button.layer.cornerRadius = 5
            button.contentHorizontalAlignment = .left
            button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
            button.accessibilityIdentifier = "\(genre.id)"
            genreScrollView.addSubview(button)
            yOffset += 80
        }
        
        genreScrollView.contentSize = CGSize(width: genreScrollView.frame.width, height: yOffset)
    }

    @objc func genreButtonTapped(_ sender: UIButton) {
        if let genreIDString = sender.accessibilityIdentifier, let genreID = Int(genreIDString) {
            if let selectedGenre = findGenreWithID(genreID) {
                let showGenreDetails = ShowGenreDetailsController(nibName: "ShowGnereDetails", bundle: nil)
                showGenreDetails.modalPresentationStyle = .fullScreen
                showGenreDetails.modalTransitionStyle = .crossDissolve
                showGenreDetails.selectedGenre = selectedGenre
                self.present(showGenreDetails, animated: true)
            }
        }
    }
    
    func findGenreWithID(_ id: Int) -> Genre? {
        return genres.first(where: { $0.id == id })
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        createGenreButtons()
    }
}
