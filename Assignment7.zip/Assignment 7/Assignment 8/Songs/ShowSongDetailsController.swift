import UIKit

class ShowSongDetailsController: UIViewController {
    var selectedSong: Song?
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var durationTextFild: UITextField!
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var albumTextField: UITextField!
    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var favouritesSwitch: UISwitch!

    
    @IBAction func deleteSongButton(_ sender: UIButton) {
        guard let selectedSong = selectedSong else {
            print("No song selected.")
            return
        }
        
        if let index = songs.firstIndex(where: { $0.id == selectedSong.id }) {
            songs.remove(at: index)
            print("Song deleted successfully.")
            
            dismiss(animated: true) {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
            }
        } else {
            print("Failed to delete song.")
        }
    }
    
    @IBAction func updateSongButton(_ sender: Any) {
        guard var selectedSong = selectedSong else {
            print("No song selected.")
            return
        }
        
        if let newTitle = titleTextField.text {
            selectedSong.title = newTitle
        }
        if let newDurationText = durationTextFild.text, let newDuration = Double(newDurationText) {
            selectedSong.duration = newDuration
        }
        
        selectedSong.favorite = favouritesSwitch.isOn
        
        if let index = songs.firstIndex(where: { $0.id == selectedSong.id }) {
            songs[index] = selectedSong
        }
        
        titleTextField.text = selectedSong.title
        durationTextFild.text = "\(selectedSong.duration)"
        
        print("Song updated successfully.")
        
        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let song = selectedSong {
            print("Song ID: \(song.id)")
            print("Title: \(song.title)")
            print("Artist ID: \(song.artistID)")
            
            titleTextField.text = song.title
            durationTextFild.text = "\(song.duration)"
            
            if let artist = artists.first(where: { $0.id == song.artistID }) {
                artistTextField.text = artist.name
            }
            if let album = albums.first(where: { $0.id == song.albumID }) {
                albumTextField.text = album.title
            }
            if let genre = genres.first(where: { $0.id == song.genreID }) {
                genreTextField.text = genre.name
            }
            
            favouritesSwitch.isOn = song.favorite
            
            artistTextField.isUserInteractionEnabled = false
            albumTextField.isUserInteractionEnabled = false
            genreTextField.isUserInteractionEnabled = false
        }

    }
    

    @IBAction func songDetailsBackButton(_ sender: UIButton) {
        selectedSong = nil
        dismiss(animated: true, completion: nil)
    }

}
