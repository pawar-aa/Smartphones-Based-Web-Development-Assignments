import UIKit

class CreateNewSongController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    
    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var albumTextField: UITextField!
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var favoritesSwitch: UISwitch!
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var durationTextField: UITextField!
    
    @IBAction func createNewSongButton(_ sender: UIButton) {
        guard let artistID = artists.first(where: { $0.name == artistTextField.text })?.id else {
            showAlert(message: "Selected artist not found.")
            return
        }
        
        guard let albumID = albums.first(where: { $0.title == albumTextField.text })?.id else {
            showAlert(message: "Selected album not found.")
            return
        }
        
        guard let genreID = genres.first(where: { $0.name == genreTextField.text })?.id else {
            showAlert(message: "Selected genre not found.")
            return
        }
        
        guard let title = titleTextField.text, !title.isEmpty else {
            showAlert(message: "Please enter song title.")
            return
        }
        
        guard let durationText = durationTextField.text, let duration = Double(durationText) else {
            showAlert(message: "Please enter a valid duration.")
            return
        }
        
        let favorite = favoritesSwitch.isOn
        guard let lastSongID = songs.map({ $0.id }).max() else {
            showAlert(message: "Unable to find the last song ID.")
            return
        }
        
        let newSong = Song(id: lastSongID + 1, artistID: artistID, albumID: albumID, genreID: genreID, title: title, duration: duration, favorite: favorite)
        
        songs.append(newSong)
        
        dismiss(animated: true) {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
        }
    }
    
    var artistPickerView = UIPickerView()
    var albumPickerView = UIPickerView()
    var genrePickerView = UIPickerView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        genreTextField.inputView = genrePickerView
        albumTextField.inputView = albumPickerView
        artistTextField.inputView = artistPickerView
        
        genreTextField.placeholder = "Select Genre"
        albumTextField.placeholder = "Select Album"
        artistTextField.placeholder = "Select Artist"
        
        genrePickerView.delegate = self
        genrePickerView.dataSource = self
        albumPickerView.delegate = self
        albumPickerView.dataSource = self
        artistPickerView.delegate = self
        artistPickerView.dataSource = self
        
        artistPickerView.tag = 1
        albumPickerView.tag = 2
        genrePickerView.tag = 3
    }
    
    @IBAction func createSongBackButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag {
        case 1:
            return artists.count
        case 2:
            return albums.count
        case 3:
            return genres.count
        default:
            return 1
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag {
        case 1:
            return artists[row].name
        case 2:
            return albums[row].title
        case 3:
            return genres[row].name
        default:
            return "Data Not Found"
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag {
        case 1:
            artistTextField.text = artists[row].name
            artistTextField.resignFirstResponder()
        case 2:
            albumTextField.text = albums[row].title
            albumTextField.resignFirstResponder()
        case 3:
            genreTextField.text = genres[row].name
            genreTextField.resignFirstResponder()
        default:
            return
        }
    }

}
