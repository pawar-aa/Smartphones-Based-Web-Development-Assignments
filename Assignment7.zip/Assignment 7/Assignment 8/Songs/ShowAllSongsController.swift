import UIKit

class ShowAllSongsController: UIViewController, UISearchBarDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(refreshSongs), name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
        songSearchBar.delegate = self
        createSongButtons()
    }
    
    @objc func refreshSongs() {
        createSongButtons()
    }
    
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            createSongButtons()
        }
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var songSearchBar: UISearchBar!
    
    
    @IBAction func songBackButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func addNewSongButton(_ sender: UIButton) {
        
        let createNewSong = CreateNewSongController(nibName: "Create Song", bundle: nil)
        createNewSong.modalPresentationStyle = .fullScreen
        createNewSong.modalTransitionStyle = .crossDissolve
        self.present(createNewSong, animated: true)
    }

    func createSongButtons() {
        scrollView.subviews.forEach { $0.removeFromSuperview() }
        
        var yOffset: CGFloat = 20
        let buttonWidth: CGFloat = scrollView.frame.width - 40
        
        let filteredSongs: [Song]
        if let searchText = songSearchBar.text, !searchText.isEmpty {
            filteredSongs = songs.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        } else {
            filteredSongs = songs
        }
        
        for song in filteredSongs {
            if let artist = artists.first(where: { $0.id == song.artistID }) {
                let button = UIButton(type: .system)
                button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 60)
                button.setTitle("\(song.title) - \(artist.name)", for: .normal)
                button.setTitleColor(.white, for: .normal)
                button.addTarget(self, action: #selector(songButtonTapped(_:)), for: .touchUpInside)
                button.backgroundColor = .black
                button.layer.cornerRadius = 5
                button.contentHorizontalAlignment = .left
                button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
                button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
                
                button.accessibilityIdentifier = "\(song.id)"
                
                scrollView.addSubview(button)
                
                yOffset += 80
            }
        }
        
        scrollView.contentSize = CGSize(width: scrollView.frame.width, height: yOffset)
    }
    
    @objc func songButtonTapped(_ sender: UIButton) {
        if let songIDString = sender.accessibilityIdentifier, let songID = Int(songIDString) {
                if let selectedSong = findSongWithID(songID) {
                    let showSongDetails = ShowSongDetailsController(nibName: "ShowSongDetails", bundle: nil)
                    showSongDetails.modalPresentationStyle = .fullScreen
                    showSongDetails.modalTransitionStyle = .crossDissolve
                    showSongDetails.selectedSong = selectedSong
                    self.present(showSongDetails, animated: true)
                }
            }
    }

    func findSongWithID(_ id: Int) -> Song? {
        return songs.first(where: { $0.id == id })
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        createSongButtons()
    }

}

