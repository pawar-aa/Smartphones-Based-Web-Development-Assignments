import UIKit
import CoreData

class ShowAllSongsViewController: UIViewController, UISearchBarDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var songSearchBar: UISearchBar!

    @IBOutlet weak var tableView: UITableView!
    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

            NotificationCenter.default.addObserver(self, selector: #selector(refreshSongs), name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(refreshSongs), name: NSNotification.Name(rawValue: "SongDeleted"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(refreshSongs), name: NSNotification.Name(rawValue: "SongUpdated"), object: nil)
        createSongButtons()
    }

    @objc func refreshSongs() {
        createSongButtons()
    }
    
       func createSongButtons() {
           scrollView.subviews.forEach { $0.removeFromSuperview() }

           var yOffset: CGFloat = 20
           let buttonHeight: CGFloat = 80
           let buttonWidth: CGFloat = scrollView.frame.width - 40

           let fetchRequest: NSFetchRequest<Song> = Song.fetchRequest()
           let searchText = songSearchBar.text ?? ""
           if !searchText.isEmpty {
               fetchRequest.predicate = NSPredicate(format: "title CONTAINS[cd] %@", searchText)
           }

           do {
                       let fetchedSongs = try managedObjectContext.fetch(fetchRequest)
                       for song in fetchedSongs {
                           if let artist = song.artist, let title = song.title {
                               let containerView = UIView(frame: CGRect(x: 20, y: yOffset, width: buttonWidth, height: buttonHeight))
                               containerView.backgroundColor = .black
                               containerView.layer.cornerRadius = 5
                               if let imageData = song.image, let songImage = UIImage(data: imageData) {
                                   let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 60, height: 60))
                                   imageView.image = songImage
                                   imageView.contentMode = .scaleAspectFill
                                   imageView.layer.cornerRadius = 5
                                   imageView.clipsToBounds = true
                                   containerView.addSubview(imageView)
                               }
                               let titleLabel = UILabel(frame: CGRect(x: 80, y: 10, width: buttonWidth - 100, height: 30))
                               titleLabel.text = "\(title) - \(artist.name ?? "")"
                               titleLabel.font = UIFont.boldSystemFont(ofSize: 16)
                               titleLabel.textColor = .white
                               containerView.addSubview(titleLabel)
                               let durationLabel = UILabel(frame: CGRect(x: 80, y: 40, width: buttonWidth - 100, height: 30))
                               durationLabel.text = "\(song.duration) sec"
                               durationLabel.font = UIFont.systemFont(ofSize: 12)
                               durationLabel.textColor = .lightGray
                               containerView.addSubview(durationLabel)
                               containerView.accessibilityIdentifier = "\(song.objectID.uriRepresentation().absoluteString)"
                               let tapGesture = UITapGestureRecognizer(target: self, action: #selector(songButtonTapped(_:)))
                               containerView.addGestureRecognizer(tapGesture)
                               containerView.isUserInteractionEnabled = true
                               scrollView.addSubview(containerView)
                               yOffset += buttonHeight + 20
                           }
                       }
                   } catch let error as NSError {
                       print("Could not fetch. \(error), \(error.userInfo)")
                   }
                   scrollView.contentSize = CGSize(width: scrollView.frame.width, height: yOffset)
       }
    
    @objc func songButtonTapped(_ sender: UITapGestureRecognizer) {
        if let containerView = sender.view,
           let songObjectIDString = containerView.accessibilityIdentifier,
           let songObjectURL = URL(string: songObjectIDString),
           let songObjectID = managedObjectContext.persistentStoreCoordinator?.managedObjectID(forURIRepresentation: songObjectURL),
           let song = try? managedObjectContext.existingObject(with: songObjectID) as? Song {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let showSongDetailsViewController = storyboard.instantiateViewController(withIdentifier: "ShowSongDetailsViewController") as? ShowSongDetailsViewController {
                showSongDetailsViewController.selectedSong = song
                self.navigationController?.pushViewController(showSongDetailsViewController, animated: true)
            }
        }
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        createSongButtons()
    }

}
