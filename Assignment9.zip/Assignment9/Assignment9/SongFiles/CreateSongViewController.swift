
import UIKit
import CoreData

class CreateSongViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var albumTextField: UITextField!
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var favoritesSwitch: UISwitch!
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var durationTextField: UITextField!
    @IBOutlet weak var songImageView: UIImageView!
    @IBOutlet weak var selectImageButton: UIButton!
    

    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()

    var artistPickerView = UIPickerView()
    var albumPickerView = UIPickerView()
    var genrePickerView = UIPickerView()
    
    var artists = [Artist]()
    var albums = [Album]()
    var genres = [Genre]()
    var selectedImage: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()

        genreTextField.inputView = genrePickerView
        albumTextField.inputView = albumPickerView
        artistTextField.inputView = artistPickerView

        genreTextField.placeholder = "Select Genre"
        albumTextField.placeholder = "Select Album"
        artistTextField.placeholder = "Select Artist"

        genrePickerView.delegate = self
        genrePickerView.dataSource = self
        albumPickerView.delegate = self
        albumPickerView.dataSource = self
        artistPickerView.delegate = self
        artistPickerView.dataSource = self

        artistPickerView.tag = 1
        albumPickerView.tag = 2
        genrePickerView.tag = 3
        
        fetchArtists()
        fetchAlbums()
        fetchGenres()

                selectImageButton.addTarget(self, action: #selector(selectImageButtonTapped(_:)), for: .touchUpInside)

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped(_:)))
        songImageView.isUserInteractionEnabled = true
        songImageView.addGestureRecognizer(tapGesture)
        
        
    }
    
    @objc func selectImageButtonTapped(_ sender: UIButton) {
            let imagePickerController = UIImagePickerController()
            imagePickerController.delegate = self
            imagePickerController.sourceType = .photoLibrary
            present(imagePickerController, animated: true, completion: nil)
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                selectedImage = image
                songImageView.image = image
                selectImageButton.isHidden = true
            }
            dismiss(animated: true, completion: nil)
        }

        @objc func imageViewTapped(_ sender: UITapGestureRecognizer) {
            selectImageButton.isHidden = false
        }
    
    func fetchArtists() {
        let fetchRequest: NSFetchRequest<Artist> = Artist.fetchRequest()

        do {
            artists = try managedObjectContext.fetch(fetchRequest)
        } catch {
            print("Error fetching artists: \(error)")
        }
    }

    func fetchAlbums() {
        let fetchRequest: NSFetchRequest<Album> = Album.fetchRequest()

        do {
            albums = try managedObjectContext.fetch(fetchRequest)
        } catch {
            print("Error fetching albums: \(error)")
        }
    }

    func fetchGenres() {
        let fetchRequest: NSFetchRequest<Genre> = Genre.fetchRequest()

        do {
            genres = try managedObjectContext.fetch(fetchRequest)
        } catch {
            print("Error fetching genres: \(error)")
        }
    }

    @IBAction func createNewSongButton(_ sender: UIButton) {
        guard let name = titleTextField.text, !name.isEmpty else {
                showAlert(message: "Please enter song title.")
                return
            }

            guard let durationText = durationTextField.text, let duration = Double(durationText) else {
                showAlert(message: "Please enter a valid duration.")
                return
            }

            guard let artistName = artistTextField.text, !artistName.isEmpty else {
                showAlert(message: "Please select an artist.")
                return
            }

            guard let albumTitle = albumTextField.text, !albumTitle.isEmpty else {
                showAlert(message: "Please select an album.")
                return
            }

            guard let genreName = genreTextField.text, !genreName.isEmpty else {
                showAlert(message: "Please select a genre.")
                return
            }

            guard let selectedImageData = selectedImage?.jpegData(compressionQuality: 1.0) else {
                showAlert(message: "Please select an image for the song.")
                return
            }

            let fetchRequest: NSFetchRequest<Song> = Song.fetchRequest()
            fetchRequest.sortDescriptors = [NSSortDescriptor(key: "id", ascending: false)]
            fetchRequest.fetchLimit = 1

            do {
                let result = try managedObjectContext.fetch(fetchRequest)
                var lastSongID: Int16 = 0
                if let lastSong = result.first {
                    lastSongID = lastSong.id
                }

                let newSong = Song(context: managedObjectContext)
                newSong.id = lastSongID + 1
                newSong.title = name
                newSong.duration = duration
                newSong.favorite = favoritesSwitch.isOn
                newSong.image = selectedImageData

                if let artist = fetchOrCreateArtist(with: artistName) {
                    newSong.artist = artist
                } else {
                    showAlert(message: "Failed to create artist.")
                    return
                }

                if let album = fetchOrCreateAlbum(with: albumTitle) {
                    newSong.album = album
                } else {
                    showAlert(message: "Failed to create album.")
                    return
                }

                if let genre = fetchOrCreateGenre(with: genreName) {
                    newSong.genre = genre
                } else {
                    showAlert(message: "Failed to create genre.")
                    return
                }

                try managedObjectContext.save()
                dismiss(animated: true) {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
                }
                
                        showAlert(message: "Song created successfully.")

                        resetFields()

                        dismiss(animated: true) {
                            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshSongs"), object: nil)
                        }
            } catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
                showAlert(message: "Failed to create song.")
            }
    }
    
    func resetFields() {
        titleTextField.text = ""
        durationTextField.text = ""
        artistTextField.text = ""
        albumTextField.text = ""
        genreTextField.text = ""
        favoritesSwitch.isOn = false
        songImageView.image = nil
        selectImageButton.isHidden = false
    }

    func fetchOrCreateArtist(with name: String) -> Artist? {
        let fetchRequest: NSFetchRequest<Artist> = Artist.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "name == %@", name)

        do {
            let results = try managedObjectContext.fetch(fetchRequest)
            if let existingArtist = results.first {
                return existingArtist
            } else {
                let newArtist = Artist(context: managedObjectContext)
                newArtist.name = name
                return newArtist
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }

    func fetchOrCreateAlbum(with title: String) -> Album? {
        let fetchRequest: NSFetchRequest<Album> = Album.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "title == %@", title)

        do {
            let results = try managedObjectContext.fetch(fetchRequest)
            if let existingAlbum = results.first {
                return existingAlbum
            } else {
                let newAlbum = Album(context: managedObjectContext)
                newAlbum.title = title
                return newAlbum
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }

    func fetchOrCreateGenre(with name: String) -> Genre? {
        let fetchRequest: NSFetchRequest<Genre> = Genre.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "name == %@", name)

        do {
            let results = try managedObjectContext.fetch(fetchRequest)
            if let existingGenre = results.first {
                return existingGenre
            } else {
                let newGenre = Genre(context: managedObjectContext)
                newGenre.name = name
                return newGenre
            }
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag {
        case 1:
            return artists.count
        case 2:
            return albums.count
        case 3:
            return genres.count
        default:
            return 0
        }
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag {
        case 1:
            return artists[row].name
        case 2:
            return albums[row].title
        case 3:
            return genres[row].name
        default:
            return nil
        }
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag {
        case 1:
            artistTextField.text = artists[row].name
        case 2:
            albumTextField.text = albums[row].title
        case 3:
            genreTextField.text = genres[row].name
        default:
            break
        }
    }

}
