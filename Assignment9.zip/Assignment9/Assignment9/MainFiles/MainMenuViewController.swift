import UIKit

class MainMenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    @IBAction func ahowAllSongsButton(_ sender: UIButton) {
    }
    
    @IBAction func showAllArtistsButton(_ sender: UIButton) {
    }
    
    
    @IBAction func showAllAlbumsButton(_ sender: Any) {
    }
    
    @IBAction func showAllGenreButton(_ sender: Any) {
    }

}
