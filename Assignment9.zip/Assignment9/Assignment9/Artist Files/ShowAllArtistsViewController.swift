

import UIKit
import CoreData

class ShowAllArtistsViewController: UIViewController, UISearchBarDelegate {
    @IBOutlet weak var artistsScrollView: UIScrollView!
    @IBOutlet weak var artistSearchBar: UISearchBar!
    
    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()
    
    var filteredArtists: [Artist] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(refreshArtists), name: NSNotification.Name(rawValue: "RefreshArtists"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshArtists), name: NSNotification.Name(rawValue: "ArtistDeleted"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshArtists), name: NSNotification.Name(rawValue: "ArtistUpdated"), object: nil)
        artistSearchBar.delegate = self
        refreshArtists()
    }
    
    @objc func refreshArtists() {
        fetchArtists()
        createArtistButtons()
    }
    
    @IBAction func showAllArtistsBackButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func fetchArtists() {
        let fetchRequest: NSFetchRequest<Artist> = Artist.fetchRequest()
        do {
            filteredArtists = try managedObjectContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    func createArtistButtons() {
        artistsScrollView.subviews.forEach { $0.removeFromSuperview() }
        
        var yOffset: CGFloat = 20 // Initial Y offset
        let buttonHeight: CGFloat = 100 // Adjust height as needed
        let buttonWidth: CGFloat = artistsScrollView.frame.width - 40 // Adjust width as needed
        
        for artist in filteredArtists {
            // Create container view
            let containerView = UIView(frame: CGRect(x: 20, y: yOffset, width: buttonWidth, height: buttonHeight))
            containerView.backgroundColor = .black
            containerView.layer.cornerRadius = 5
            
            // Add artist image
            let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 80, height: 80))
            imageView.contentMode = .scaleAspectFit
            imageView.layer.cornerRadius = 5
            imageView.clipsToBounds = true
            imageView.backgroundColor = .gray
            
            // Check if artist has an image
            if let imageData = artist.image, let image = UIImage(data: imageData) {
                imageView.image = image
            } else {
                // If no image found, you can display a placeholder image or leave it blank
                imageView.image = UIImage(named: "placeholder_image") // Provide the name of your placeholder image
            }
            containerView.addSubview(imageView)
            
            // Add artist name label
            let nameLabel = UILabel(frame: CGRect(x: 100, y: 10, width: buttonWidth - 120, height: 80))
            nameLabel.text = artist.name
            nameLabel.textColor = .white
            nameLabel.font = UIFont.boldSystemFont(ofSize: 16)
            nameLabel.numberOfLines = 0 // Allow multiple lines for long artist names
            containerView.addSubview(nameLabel)
            
            // Set accessibility identifier to artist ID
            containerView.accessibilityIdentifier = "\(artist.objectID.uriRepresentation().absoluteString)"
            
            // Add gesture recognizer to containerView
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(artistButtonTapped(_:)))
            containerView.addGestureRecognizer(tapGesture)
            containerView.isUserInteractionEnabled = true
            
            // Add container view to scroll view
            artistsScrollView.addSubview(containerView)
            
            // Update Y offset for the next button
            yOffset += buttonHeight + 20 // Adjust spacing as needed
        }
        
        // Set content size of scroll view based on the total height of buttons
        artistsScrollView.contentSize = CGSize(width: artistsScrollView.frame.width, height: yOffset)
    }
    
    
    @objc func artistButtonTapped(_ sender: UITapGestureRecognizer) {
        if let containerView = sender.view,
           let artistObjectIDString = containerView.accessibilityIdentifier,
           let artistObjectURL = URL(string: artistObjectIDString),
           let artistObjectID = managedObjectContext.persistentStoreCoordinator?.managedObjectID(forURIRepresentation: artistObjectURL),
           let artist = try? managedObjectContext.existingObject(with: artistObjectID) as? Artist {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil) // Assuming your storyboard name is "Main"
            if let showArtistDetailsViewController = storyboard.instantiateViewController(withIdentifier: "ArtistDetailsViewController") as? ArtistDetailsViewController {
                showArtistDetailsViewController.selectedArtist = artist
                self.navigationController?.pushViewController(showArtistDetailsViewController, animated: true)
            }
        }
    }

        // Implement UISearchBarDelegate method for search functionality
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            if !searchText.isEmpty {
                filteredArtists = filteredArtists.filter { $0.name?.lowercased().contains(searchText.lowercased()) ?? false }
            } else {
                fetchArtists()
            }
            createArtistButtons()
        }
    
}
