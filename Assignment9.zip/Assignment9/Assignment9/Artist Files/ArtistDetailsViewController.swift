
import UIKit
import CoreData

class ArtistDetailsViewController: UIViewController {

    @IBOutlet weak var artistsSongsScrollView: UIScrollView!
        @IBOutlet weak var nameTextField: UITextField!
        @IBOutlet weak var artistImageView: UIImageView!
        
        var selectedArtist: Artist?
        
        let managedObjectContext: NSManagedObjectContext = {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            return appDelegate.persistentContainer.viewContext
        }()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            if let artist = selectedArtist {
                print("Artist ID: \(artist.id), Artist Name: \(artist.name ?? "")")
                nameTextField.text = artist.name
                if let imageData = artist.image, let image = UIImage(data: imageData) {
                    artistImageView.image = image
                }
                displayArtistSongs()
            }
        }
        
        @IBAction func deleteArtistButton(_ sender: UIButton) {
            guard let selectedArtist = selectedArtist else {
                print("No artist selected.")
                return
            }
            
            let songsFetchRequest: NSFetchRequest<Song> = Song.fetchRequest()
            songsFetchRequest.predicate = NSPredicate(format: "artist == %@", selectedArtist)
            
            do {
                let artistSongs = try managedObjectContext.fetch(songsFetchRequest)
                if !artistSongs.isEmpty {
                    let alert = UIAlertController(title: "Cannot Delete Artist", message: "Artist cannot be deleted because it has one or more songs", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                } else {
                    managedObjectContext.delete(selectedArtist)
                    try managedObjectContext.save()
                    print("Artist deleted successfully.")
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ArtistDeleted"), object: nil)
                    navigationController?.popViewController(animated: true) // Dismiss the view controller
                }
            } catch let error as NSError {
                print("Error deleting artist: \(error), \(error.userInfo)")
            }
        }
        
        @IBAction func updateArtistButton(_ sender: UIButton) {
            guard var selectedArtist = selectedArtist else {
                print("No artist selected.")
                return
            }
            
            if let newName = nameTextField.text {
                selectedArtist.name = newName
            }
            
            do {
                try managedObjectContext.save()
                print("Artist updated successfully.")
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ArtistUpdated"), object: nil)
                navigationController?.popViewController(animated: true) // Dismiss the view controller
            } catch let error as NSError {
                print("Could not update artist. \(error), \(error.userInfo)")
            }
        }
        
        func displayArtistSongs() {
            guard let selectedArtist = selectedArtist else { return }
            
            let songsFetchRequest: NSFetchRequest<Song> = Song.fetchRequest()
            songsFetchRequest.predicate = NSPredicate(format: "artist == %@", selectedArtist)
            
            do {
                let artistSongs = try managedObjectContext.fetch(songsFetchRequest)
                var yOffset: CGFloat = 20
                let buttonWidth: CGFloat = artistsSongsScrollView.frame.width - 40
                
                for song in artistSongs {
                    let button = UIButton(type: .system)
                    button.frame = CGRect(x: 20, y: yOffset, width: buttonWidth, height: 30)
                    button.setTitle(song.title, for: .normal)
                    button.setTitleColor(.black, for: .normal)
                    button.backgroundColor = .lightGray
                    button.layer.cornerRadius = 5
                    
                    button.accessibilityIdentifier = song.objectID.uriRepresentation().absoluteString
                    
                    artistsSongsScrollView.addSubview(button)
                    
                    yOffset += 40
                }
                
                artistsSongsScrollView.contentSize = CGSize(width: artistsSongsScrollView.frame.width, height: yOffset)
            } catch let error as NSError {
                print("Could not fetch songs. \(error), \(error.userInfo)")
            }
        }
}
