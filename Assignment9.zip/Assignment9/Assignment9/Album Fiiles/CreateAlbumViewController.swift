import UIKit
import CoreData

class CreateAlbumViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var albumTitleTextField: UITextField!
    @IBOutlet weak var albumImageView: UIImageView!
    @IBOutlet weak var selectImageButton: UIButton!

    @IBOutlet weak var datePicker: UIDatePicker! // Updated: Date picker IBOutlet

    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()

    var artists = [Artist]()
    var artistPickerView = UIPickerView()
    var selectedImage: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up artist picker
        artistPickerView.delegate = self
        artistPickerView.dataSource = self
        artistTextField.inputView = artistPickerView
        artistTextField.placeholder = "Select Artist"

        fetchArtists()

        // Set up the image selection button
        selectImageButton.addTarget(self, action: #selector(selectImageButtonTapped(_:)), for: .touchUpInside)

        // Set up the image view tap gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped(_:)))
        albumImageView.isUserInteractionEnabled = true
        albumImageView.addGestureRecognizer(tapGesture)
    }

    @objc func selectImageButtonTapped(_ sender: UIButton) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            selectedImage = image
            albumImageView.image = image
            selectImageButton.isHidden = true
        }
        dismiss(animated: true, completion: nil)
    }

    @objc func imageViewTapped(_ sender: UITapGestureRecognizer) {
        selectImageButton.isHidden = false
    }

    func fetchArtists() {
        let fetchRequest: NSFetchRequest<Artist> = Artist.fetchRequest()

        do {
            artists = try managedObjectContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Error fetching artists: \(error.localizedDescription)")
        }
    }

    @IBAction func createAlbumButton(_ sender: UIButton) {
        guard let artistName = artistTextField.text, !artistName.isEmpty else {
            showAlert(message: "Please select an artist.")
            return
        }

        guard let selectedArtist = artists.first(where: { $0.name == artistName }) else {
            showAlert(message: "Selected artist not found.")
            return
        }

        guard let albumTitle = albumTitleTextField.text, !albumTitle.isEmpty else {
            showAlert(message: "Please enter album title.")
            return
        }

        // Get the selected release date from the date picker
        let releaseDate = datePicker.date

        let newAlbum = Album(context: managedObjectContext)
        newAlbum.title = albumTitle
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let releaseDateString = dateFormatter.string(from: releaseDate)
        newAlbum.releaseDate = releaseDateString
        
        newAlbum.artist = selectedArtist
        if let imageData = selectedImage?.jpegData(compressionQuality: 1.0) {
            newAlbum.image = imageData
        }

        do {
            try managedObjectContext.save()
            showAlert(message: "\(albumTitle) added as a new album.")
            resetFields()
            dismiss(animated: true) {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAlbums"), object: nil)
            }
        } catch let error as NSError {
            print("Error saving album: \(error.localizedDescription)")
            showAlert(message: "Failed to add album.")
        }
    }

    func resetFields() {
        artistTextField.text = ""
        albumTitleTextField.text = ""
        albumImageView.image = nil
        selectImageButton.isHidden = false
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    // UIPickerViewDataSource & UIPickerViewDelegate

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return artists.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return artists[row].name
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        artistTextField.text = artists[row].name
    }
}
