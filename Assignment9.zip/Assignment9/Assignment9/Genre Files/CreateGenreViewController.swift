import UIKit
import CoreData

class CreateGenreViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var genreImageView: UIImageView!
    @IBOutlet weak var selectImageButton: UIButton!
    @IBOutlet weak var createGenreButton: UIButton!
    
    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()
    
    var genres = [Genre]()
    var selectedImage: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up the image selection button
        selectImageButton.addTarget(self, action: #selector(selectImageButtonTapped(_:)), for: .touchUpInside)
        
        // Set up the image view tap gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped(_:)))
        genreImageView.isUserInteractionEnabled = true
        genreImageView.addGestureRecognizer(tapGesture)
        
        fetchGenres()
        
        // Set up "Create Genre" button
        createGenreButton.addTarget(self, action: #selector(createGenreButtonTapped(_:)), for: .touchUpInside)
    }
    
    @objc func selectImageButtonTapped(_ sender: UIButton) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true, completion: nil)
    }
    
    @objc func createGenreButtonTapped(_ sender: UIButton) {
        // Check if name is provided
        guard let name = nameTextField.text, !name.isEmpty else {
            showAlert(message: "Please enter genre name.")
            return
        }
        
        guard let selectedImageData = selectedImage?.jpegData(compressionQuality: 1.0) else {
            showAlert(message: "Please select an image for the Genre.")
            return
        }
        
        // Create a new genre entity
        let genreEntity = NSEntityDescription.entity(forEntityName: "Genre", in: managedObjectContext)!
        let newGenre = NSManagedObject(entity: genreEntity, insertInto: managedObjectContext) as! Genre
        
        // Set genre properties
        newGenre.name = name
        // Set genre image if available
        if let imageData = selectedImage?.jpegData(compressionQuality: 1.0) {
            newGenre.image = imageData
        }
        
        // Save the changes to Core Data
        do {
            try managedObjectContext.save()
            
            // Show success message
            showAlert(message: "Genre created successfully.")
            
            // Reset all fields
            resetFields()
            
            dismiss(animated: true) {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshGenres"), object: nil)
            }
        } catch let error as NSError {
            print("Error saving genre: \(error), \(error.userInfo)")
            showAlert(message: "Failed to create genre.")
        }
    }
    
    func resetFields() {
        nameTextField.text = ""
        genreImageView.image = nil
        selectImageButton.isHidden = false
    }
    
    // Function to display an alert with a given message
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            selectedImage = image
            genreImageView.image = image
            selectImageButton.isHidden = true // Hide the button when an image is selected
        }
        dismiss(animated: true, completion: nil)
    }
    
    @objc func imageViewTapped(_ sender: UITapGestureRecognizer) {
        selectImageButton.isHidden = false // Show the button when the image view is tapped
    }
    
    func fetchGenres() {
        let fetchRequest: NSFetchRequest<Genre> = Genre.fetchRequest()
        
        do {
            genres = try managedObjectContext.fetch(fetchRequest)
        } catch {
            print("Error fetching genres: \(error)")
        }
    }
    
    // Add any additional methods or functionality here as needed
}
