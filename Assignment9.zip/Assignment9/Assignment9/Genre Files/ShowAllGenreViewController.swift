import UIKit
import CoreData

class ShowAllGenreViewController: UIViewController, UISearchBarDelegate {
    @IBOutlet weak var genresScrollView: UIScrollView!
    @IBOutlet weak var genreSearchBar: UISearchBar!
    
    let managedObjectContext: NSManagedObjectContext = {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }()
    
    var filteredGenres: [Genre] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(refreshGenres), name: NSNotification.Name(rawValue: "RefreshGenres"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshGenres), name: NSNotification.Name(rawValue: "GenreDeleted"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshGenres), name: NSNotification.Name(rawValue: "GenreUpdated"), object: nil)
        genreSearchBar.delegate = self
        refreshGenres()
    }
    
    @objc func refreshGenres() {
        fetchGenres()
        createGenreButtons()
    }
    
    @IBAction func showAllGenresBackButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func fetchGenres() {
        let fetchRequest: NSFetchRequest<Genre> = Genre.fetchRequest()
        do {
            filteredGenres = try managedObjectContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    func createGenreButtons() {
        genresScrollView.subviews.forEach { $0.removeFromSuperview() }
        
        var yOffset: CGFloat = 20 // Initial Y offset
        let buttonHeight: CGFloat = 100 // Adjust height as needed
        let buttonWidth: CGFloat = genresScrollView.frame.width - 40 // Adjust width as needed
        
        for genre in filteredGenres {
            // Create container view
            let containerView = UIView(frame: CGRect(x: 20, y: yOffset, width: buttonWidth, height: buttonHeight))
            containerView.backgroundColor = .black
            containerView.layer.cornerRadius = 5
            
            // Add genre image
            let imageView = UIImageView(frame: CGRect(x: 10, y: 10, width: 80, height: 80))
            imageView.contentMode = .scaleAspectFit
            imageView.layer.cornerRadius = 5
            imageView.clipsToBounds = true
            imageView.backgroundColor = .gray
            
            // Check if genre has an image
            if let imageData = genre.image, let image = UIImage(data: imageData) {
                imageView.image = image
            } else {
                // If no image found, you can display a placeholder image or leave it blank
                imageView.image = UIImage(named: "placeholder_image") // Provide the name of your placeholder image
            }
            containerView.addSubview(imageView)
            
            // Add genre name label
            let nameLabel = UILabel(frame: CGRect(x: 100, y: 10, width: buttonWidth - 120, height: 80))
            nameLabel.text = genre.name
            nameLabel.textColor = .white
            nameLabel.font = UIFont.boldSystemFont(ofSize: 16)
            nameLabel.numberOfLines = 0 // Allow multiple lines for long genre names
            containerView.addSubview(nameLabel)
            
            // Set accessibility identifier to genre ID
            containerView.accessibilityIdentifier = "\(genre.objectID.uriRepresentation().absoluteString)"
            
            // Add gesture recognizer to containerView
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(genreButtonTapped(_:)))
            containerView.addGestureRecognizer(tapGesture)
            containerView.isUserInteractionEnabled = true
            
            // Add container view to scroll view
            genresScrollView.addSubview(containerView)
            
            // Update Y offset for the next button
            yOffset += buttonHeight + 20 // Adjust spacing as needed
        }
        
        // Set content size of scroll view based on the total height of buttons
        genresScrollView.contentSize = CGSize(width: genresScrollView.frame.width, height: yOffset)
    }
    
    
    @objc func genreButtonTapped(_ sender: UITapGestureRecognizer) {
        if let containerView = sender.view,
           let genreObjectIDString = containerView.accessibilityIdentifier,
           let genreObjectURL = URL(string: genreObjectIDString),
           let genreObjectID = managedObjectContext.persistentStoreCoordinator?.managedObjectID(forURIRepresentation: genreObjectURL),
           let genre = try? managedObjectContext.existingObject(with: genreObjectID) as? Genre {
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil) // Assuming your storyboard name is "Main"
            if let showGenreDetailsViewController = storyboard.instantiateViewController(withIdentifier: "GenreDetailsViewController") as? GenreDetailsViewController {
                showGenreDetailsViewController.selectedGenre = genre
                self.navigationController?.pushViewController(showGenreDetailsViewController, animated: true)
            }
        }
    }

    // Implement UISearchBarDelegate method for search functionality
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if !searchText.isEmpty {
            filteredGenres = filteredGenres.filter { $0.name?.lowercased().contains(searchText.lowercased()) ?? false }
        } else {
            fetchGenres()
        }
        createGenreButtons()
    }
    
}
